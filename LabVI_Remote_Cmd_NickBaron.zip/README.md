# LabVI_Remote_Cmd
Ece 456 Lab 6: This lab will work with a server and a client to send info with both udp and tcp

by Nick Baron 830278807

You need to have python3!

To run the server:

-cd into the directory that contains the server.py.
-run the py file using the python3 command: python3 server.py {server_port}

To run the client: on a new machine

-cd into the directory containing the client.py file.
-run the client using the command: python3 client.py {server_ip_address} {server_ip_port} {number of loops} {time_delay} {command}
